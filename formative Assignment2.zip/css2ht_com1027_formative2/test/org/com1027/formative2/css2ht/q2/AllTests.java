/**
 * AllTests.java
 */

package org.com1027.formative2.css2ht.q2;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 * This class defines the JUnit4 test suite for the rainfall coursework.
 * 
 * @author Matthew Casey
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({ RainfallTest.class, RainfallYearTest.class })
public class AllTests {
}
